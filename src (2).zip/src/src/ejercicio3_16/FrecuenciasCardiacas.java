package ejercicio3_16;

import java.time.LocalDate;
import java.time.Period;

public class FrecuenciasCardiacas {
    private String primerNombre;
    private String apellido;
    private int mesNacimiento;
    private int diaNacimiento;
    private int añoNacimiento;
    public FrecuenciasCardiacas(String primerNombre, String apellido, int mesNacimiento, int diaNacimiento, int anioNacimiento) {
        this.primerNombre = primerNombre;
        this.apellido = apellido;
        this.mesNacimiento = mesNacimiento;
        this.diaNacimiento = diaNacimiento;
        this.añoNacimiento = anioNacimiento;
    }
    public void establecerPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String obtenerPrimerNombre() {
        return primerNombre;
    }

    public void establecerApellido(String apellido) {
        this.apellido = apellido;
    }

    public String obtenerApellido() {
        return apellido;
    }

    public void establecerMesNacimiento(int mesNacimiento) {
        this.mesNacimiento = mesNacimiento;
    }

    public int obtenerMesNacimiento() {
        return mesNacimiento;
    }

    public void establecerDiaNacimiento(int diaNacimiento) {
        this.diaNacimiento = diaNacimiento;
    }

    public int obtenerDiaNacimiento() {
        return diaNacimiento;
    }

    public void establecerAnioNacimiento(int anioNacimiento) {
        this.añoNacimiento = anioNacimiento;
    }

    public int obtenerAnioNacimiento() {
        return añoNacimiento;
    }

    // Método para calcular la edad
    public int calcularEdad() {
        LocalDate fechaNacimiento = LocalDate.of(añoNacimiento, mesNacimiento, diaNacimiento);
        LocalDate fechaActual = LocalDate.now();
        return Period.between(fechaNacimiento, fechaActual).getYears();
    }
    public int calcularFrecuenciaCardiacaMaxima() {
        return 220 - calcularEdad();
    }
    // Método para calcular la frecuencia cardiaca esperada (devuelve un rango en formato String)
    public String calcularFrecuenciaCardiacaEsperada() {
        int frecMaxima = calcularFrecuenciaCardiacaMaxima();
        double limiteInferior = frecMaxima * 0.50;
        double limiteSuperior = frecMaxima * 0.85;
        return String.format("%.0f - %.0f", limiteInferior, limiteSuperior);
    }
}