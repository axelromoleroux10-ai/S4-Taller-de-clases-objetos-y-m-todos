package ejercicio3_16;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PruebaFrecuenciasCardiacas {
    public static void main(String[] args) {

        // =================================================================
        // PARTE 1: Ingreso de datos mediante la consola usando Scanner
        // =================================================================
        Scanner entrada = new Scanner(System.in);

        System.out.println("--- CALCULADORA DE FRECUENCIA CARDIACA (Scanner) ---");
        System.out.print("Ingrese su primer nombre: ");
        String nombreScanner = entrada.nextLine();

        System.out.print("Ingrese su apellido: ");
        String apellidoScanner = entrada.nextLine();

        int mesScanner;
        do {
            System.out.print("Ingrese su mes de nacimiento (1-12): ");
            mesScanner = entrada.nextInt();
            if (mesScanner <= 0 || mesScanner > 12) {
                System.out.println("Error: El mes debe ser un número positivo entre 1 y 12.");
            }
        } while (mesScanner <= 0 || mesScanner > 12);

        int diaScanner;
        do {
            System.out.print("Ingrese su día de nacimiento (1-31): ");
            diaScanner = entrada.nextInt();
            if (diaScanner <= 0 || diaScanner > 31) {
                System.out.println("Error: El día debe ser un número positivo válido (1-31).");
            }
        } while (diaScanner <= 0 || diaScanner > 31);

        int añoScanner;
        do {
            System.out.print("Ingrese su año de nacimiento (ej. 1990): ");
            añoScanner = entrada.nextInt();
            if (añoScanner <= 0) {
                System.out.println("Error: El año debe ser un número positivo.");
            }
        } while (añoScanner <= 0);

        FrecuenciasCardiacas persona1 = new FrecuenciasCardiacas(nombreScanner, apellidoScanner, mesScanner, diaScanner, añoScanner);

        // Imprimir resultados
        System.out.println("\n*** RESULTADOS ***");
        System.out.printf("Nombre completo: %s %s%n", persona1.obtenerPrimerNombre(), persona1.obtenerApellido());
        System.out.printf("Fecha de nacimiento: %d/%d/%d%n", persona1.obtenerDiaNacimiento(), persona1.obtenerMesNacimiento(), persona1.obtenerAnioNacimiento());
        System.out.printf("Edad: %d años%n", persona1.calcularEdad());
        System.out.printf("Frecuencia cardiaca máxima: %d ppm%n", persona1.calcularFrecuenciaCardiacaMaxima());
        System.out.printf("Rango de frecuencia cardiaca esperada: %s ppm%n", persona1.calcularFrecuenciaCardiacaEsperada());

        // =================================================================
        // PARTE 2: Ingreso de datos mediante ventanas emergentes (JOptionPane)
        // =================================================================
        JOptionPane.showMessageDialog(null, "Calculadora de Frecuencia Cardiaca\n(Ventanas Emergentes)");

        String nombreVentana = JOptionPane.showInputDialog("Ingrese su primer nombre:");
        String apellidoVentana = JOptionPane.showInputDialog("Ingrese su apellido:");

        int mesVentana = 0;
        do {
            String mesStr = JOptionPane.showInputDialog("Ingrese su mes de nacimiento (1-12):");
            mesVentana = Integer.parseInt(mesStr);
            if (mesVentana <= 0 || mesVentana > 12) {
                JOptionPane.showMessageDialog(null, "Error: El mes debe ser un número positivo entre 1 y 12.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (mesVentana <= 0 || mesVentana > 12);

        int diaVentana = 0;
        do {
            String diaStr = JOptionPane.showInputDialog("Ingrese su día de nacimiento (1-31):");
            diaVentana = Integer.parseInt(diaStr);
            if (diaVentana <= 0 || diaVentana > 31) {
                JOptionPane.showMessageDialog(null, "Error: El día debe ser un número positivo válido (1-31).", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (diaVentana <= 0 || diaVentana > 31);

        int añoVentana = 0;
        do {
            String anioStr = JOptionPane.showInputDialog("Ingrese su año de nacimiento (ej. 1990):");
            añoVentana = Integer.parseInt(anioStr);
            if (añoVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El año debe ser un número positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (añoVentana <= 0);

        FrecuenciasCardiacas persona2 = new FrecuenciasCardiacas(nombreVentana, apellidoVentana, mesVentana, diaVentana, añoVentana);

        String mensajeSalida = String.format(
                "*** RESULTADOS ***\n" +
                        "Nombre completo: %s %s\n" +
                        "Fecha de nacimiento: %d/%d/%d\n" +
                        "Edad: %d años\n" +
                        "Frecuencia cardiaca máxima: %d ppm\n" +
                        "Rango de frecuencia cardiaca esperada: %s ppm",
                persona2.obtenerPrimerNombre(), persona2.obtenerApellido(),
                persona2.obtenerDiaNacimiento(), persona2.obtenerMesNacimiento(), persona2.obtenerAnioNacimiento(),
                persona2.calcularEdad(),
                persona2.calcularFrecuenciaCardiacaMaxima(),
                persona2.calcularFrecuenciaCardiacaEsperada()
        );

        JOptionPane.showMessageDialog(null, mensajeSalida, "Resultados Frecuencia Cardiaca", JOptionPane.INFORMATION_MESSAGE);

        entrada.close();
    }
}