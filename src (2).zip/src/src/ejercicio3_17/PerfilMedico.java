package ejercicio3_17;

import java.time.LocalDate;
import java.time.Period;

public class PerfilMedico {
    private String primerNombre;
    private String apellido;
    private String sexo;
    private int mesNacimiento;
    private int diaNacimiento;
    private int anioNacimiento;
    private double alturaEnCentimetros;
    private double pesoEnKilogramos;

    // Constructor
    public PerfilMedico(String primerNombre, String apellido, String sexo, int mesNacimiento,
                        int diaNacimiento, int anioNacimiento, double alturaEnCentimetros, double pesoEnKilogramos) {
        this.primerNombre = primerNombre;
        this.apellido = apellido;
        this.sexo = sexo;
        this.mesNacimiento = mesNacimiento;
        this.diaNacimiento = diaNacimiento;
        this.anioNacimiento = anioNacimiento;
        this.alturaEnCentimetros = alturaEnCentimetros;
        this.pesoEnKilogramos = pesoEnKilogramos;
    }
    public void establecerPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }
    public String obtenerPrimerNombre() {
        return primerNombre;
    }
    public void establecerApellido(String apellido) {
        this.apellido = apellido;
    }
    public String obtenerApellido() {
        return apellido;
    }
    public void establecerSexo(String sexo) {
        this.sexo = sexo;
    }
    public String obtenerSexo() {
        return sexo;
    }
    public void establecerMesNacimiento(int mesNacimiento) {
        this.mesNacimiento = mesNacimiento;
    }
    public int obtenerMesNacimiento() {
        return mesNacimiento;
    }
    public void establecerDiaNacimiento(int diaNacimiento) {
        this.diaNacimiento = diaNacimiento;
    }
    public int obtenerDiaNacimiento() {
        return diaNacimiento;
    }
    public void establecerAnioNacimiento(int anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
    }
    public int obtenerAnioNacimiento() {
        return anioNacimiento;
    }
    public void establecerAlturaEnCentimetros(double alturaEnCentimetros) {
        this.alturaEnCentimetros = alturaEnCentimetros;
    }
    public double obtenerAlturaEnCentimetros() {
        return alturaEnCentimetros;
    }
    public void establecerPesoEnKilogramos(double pesoEnKilogramos) {
        this.pesoEnKilogramos = pesoEnKilogramos;
    }
    public double obtenerPesoEnKilogramos() {
        return pesoEnKilogramos;
    }
    public int calcularEdad() {
        LocalDate fechaNacimiento = LocalDate.of(anioNacimiento, mesNacimiento, diaNacimiento);
        LocalDate fechaActual = LocalDate.now();
        return Period.between(fechaNacimiento, fechaActual).getYears();
    }
    public int calcularFrecuenciaCardiacaMaxima() {
        return 220 - calcularEdad();
    }
    public String calcularFrecuenciaCardiacaEsperada() {
        int frecMaxima = calcularFrecuenciaCardiacaMaxima();
        double limiteInferior = frecMaxima * 0.50;
        double limiteSuperior = frecMaxima * 0.85;
        return String.format("%.0f - %.0f", limiteInferior, limiteSuperior);
    }
    public double calcularBMI() {
        // La altura se convierte de centímetros a metros para la fórmula
        double alturaEnMetros = alturaEnCentimetros / 100.0;
        return pesoEnKilogramos / (alturaEnMetros * alturaEnMetros);
    }
}