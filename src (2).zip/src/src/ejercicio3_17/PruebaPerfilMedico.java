package ejercicio3_17;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PruebaPerfilMedico {
    public static void main(String[] args) {

        String tablaBMI = "\n--- VALORES DE BMI ---\n" +
                "Bajo peso:  menos de 18.5\n" +
                "Normal:     entre 18.5 y 24.9\n" +
                "Sobrepeso:  entre 25 y 29.9\n" +
                "Obeso:      30 o más\n";

        // =================================================================
        // PARTE 1: Ingreso de datos mediante la consola usando Scanner
        // =================================================================
        Scanner entrada = new Scanner(System.in);

        System.out.println("--- CREACIÓN DE PERFIL MÉDICO (Consola) ---");
        System.out.print("Ingrese el primer nombre: ");
        String nombreScanner = entrada.nextLine();

        System.out.print("Ingrese el apellido: ");
        String apellidoScanner = entrada.nextLine();

        System.out.print("Ingrese el sexo (ej. Masculino/Femenino): ");
        String sexoScanner = entrada.nextLine();

        int mesScanner;
        do {
            System.out.print("Ingrese el mes de nacimiento (1-12): ");
            mesScanner = entrada.nextInt();
            if (mesScanner <= 0 || mesScanner > 12) {
                System.out.println("Error: El mes debe ser un número entre 1 y 12.");
            }
        } while (mesScanner <= 0 || mesScanner > 12);

        int diaScanner;
        do {
            System.out.print("Ingrese el día de nacimiento (1-31): ");
            diaScanner = entrada.nextInt();
            if (diaScanner <= 0 || diaScanner > 31) {
                System.out.println("Error: El día debe ser un número válido (1-31).");
            }
        } while (diaScanner <= 0 || diaScanner > 31);

        int anioScanner;
        do {
            System.out.print("Ingrese el año de nacimiento: ");
            anioScanner = entrada.nextInt();
            if (anioScanner <= 0) {
                System.out.println("Error: El año debe ser un número positivo.");
            }
        } while (anioScanner <= 0);

        double alturaScanner;
        do {
            System.out.print("Ingrese la altura en centímetros (mayor a 0): ");
            alturaScanner = entrada.nextDouble();
            if (alturaScanner <= 0) {
                System.out.println("Error: La altura debe ser un valor positivo.");
            }
        } while (alturaScanner <= 0);

        double pesoScanner;
        do {
            System.out.print("Ingrese el peso en kilogramos (mayor a 0): ");
            pesoScanner = entrada.nextDouble();
            if (pesoScanner <= 0) {
                System.out.println("Error: El peso debe ser un valor positivo.");
            }
        } while (pesoScanner <= 0);

        PerfilMedico paciente1 = new PerfilMedico(nombreScanner, apellidoScanner, sexoScanner,
                mesScanner, diaScanner, anioScanner,
                alturaScanner, pesoScanner);

        System.out.println("\n*** RESUMEN DEL PERFIL MÉDICO ***");
        System.out.printf("Nombre: %s %s%n", paciente1.obtenerPrimerNombre(), paciente1.obtenerApellido());
        System.out.printf("Sexo: %s%n", paciente1.obtenerSexo());
        System.out.printf("Fecha de nacimiento: %d/%d/%d%n", paciente1.obtenerDiaNacimiento(),
                paciente1.obtenerMesNacimiento(), paciente1.obtenerAnioNacimiento());
        System.out.printf("Altura: %.2f cm%n", paciente1.obtenerAlturaEnCentimetros());
        System.out.printf("Peso: %.2f kg%n", paciente1.obtenerPesoEnKilogramos());

        System.out.println("\n--- ANÁLISIS DE SALUD ---");
        System.out.printf("Edad: %d años%n", paciente1.calcularEdad());
        System.out.printf("Frecuencia Cardiaca Máxima: %d ppm%n", paciente1.calcularFrecuenciaCardiacaMaxima());
        System.out.printf("Rango de Frecuencia Cardiaca Esperada: %s ppm%n", paciente1.calcularFrecuenciaCardiacaEsperada());
        System.out.printf("Índice de Masa Corporal (BMI): %.2f%n", paciente1.calcularBMI());
        System.out.println(tablaBMI);

        // =================================================================
        // PARTE 2: Ingreso de datos mediante ventanas emergentes (JOptionPane)
        // =================================================================
        JOptionPane.showMessageDialog(null, "A continuación, crearemos otro perfil médico usando ventanas emergentes.");

        String nombreVentana = JOptionPane.showInputDialog("Ingrese el primer nombre:");
        String apellidoVentana = JOptionPane.showInputDialog("Ingrese el apellido:");
        String sexoVentana = JOptionPane.showInputDialog("Ingrese el sexo:");

        int mesVentana = 0;
        do {
            String mesStr = JOptionPane.showInputDialog("Ingrese el mes de nacimiento (1-12):");
            mesVentana = Integer.parseInt(mesStr);
            if (mesVentana <= 0 || mesVentana > 12) {
                JOptionPane.showMessageDialog(null, "Error: El mes debe ser un número entre 1 y 12.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (mesVentana <= 0 || mesVentana > 12);

        int diaVentana = 0;
        do {
            String diaStr = JOptionPane.showInputDialog("Ingrese el día de nacimiento (1-31):");
            diaVentana = Integer.parseInt(diaStr);
            if (diaVentana <= 0 || diaVentana > 31) {
                JOptionPane.showMessageDialog(null, "Error: El día debe ser un número válido (1-31).", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (diaVentana <= 0 || diaVentana > 31);

        int añoVentana = 0;
        do {
            String anioStr = JOptionPane.showInputDialog("Ingrese el año de nacimiento:");
            añoVentana = Integer.parseInt(anioStr);
            if (añoVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El año debe ser un número positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (añoVentana <= 0);

        double alturaVentana = 0.0;
        do {
            String alturaStr = JOptionPane.showInputDialog("Ingrese la altura en centímetros (mayor a 0):");
            alturaVentana = Double.parseDouble(alturaStr);
            if (alturaVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: La altura debe ser un valor positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (alturaVentana <= 0);

        double pesoVentana = 0.0;
        do {
            String pesoStr = JOptionPane.showInputDialog("Ingrese el peso en kilogramos (mayor a 0):");
            pesoVentana = Double.parseDouble(pesoStr);
            if (pesoVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El peso debe ser un valor positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (pesoVentana <= 0);

        PerfilMedico paciente2 = new PerfilMedico(nombreVentana, apellidoVentana, sexoVentana,
                mesVentana, diaVentana, añoVentana,
                alturaVentana, pesoVentana);

        String mensajeSalida = String.format(
                "*** RESUMEN DEL PERFIL MÉDICO ***\n" +
                        "Nombre: %s %s\n" +
                        "Sexo: %s\n" +
                        "Fecha de nacimiento: %d/%d/%d\n" +
                        "Altura: %.2f cm\n" +
                        "Peso: %.2f kg\n\n" +
                        "--- ANÁLISIS DE SALUD ---\n" +
                        "Edad: %d años\n" +
                        "Frecuencia Cardiaca Máxima: %d ppm\n" +
                        "Rango de Frecuencia Cardiaca Esperada: %s ppm\n" +
                        "Índice de Masa Corporal (BMI): %.2f\n" +
                        "%s",
                paciente2.obtenerPrimerNombre(), paciente2.obtenerApellido(),
                paciente2.obtenerSexo(),
                paciente2.obtenerDiaNacimiento(), paciente2.obtenerMesNacimiento(), paciente2.obtenerAnioNacimiento(),
                paciente2.obtenerAlturaEnCentimetros(),
                paciente2.obtenerPesoEnKilogramos(),
                paciente2.calcularEdad(),
                paciente2.calcularFrecuenciaCardiacaMaxima(),
                paciente2.calcularFrecuenciaCardiacaEsperada(),
                paciente2.calcularBMI(),
                tablaBMI
        );

        JOptionPane.showMessageDialog(null, mensajeSalida, "Resumen Perfil Médico", JOptionPane.INFORMATION_MESSAGE);

        entrada.close();
    }
}