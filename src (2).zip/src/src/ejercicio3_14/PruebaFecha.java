package ejercicio3_14;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PruebaFecha {
    public static void main(String[] args) {

        // =================================================================
        // PARTE 1: Ingreso de datos mediante la consola usando Scanner
        // =================================================================
        Scanner entrada = new Scanner(System.in);

        System.out.println("--- CREACIÓN DE FECHA (Consola / Scanner) ---");

        int mesScanner;
        do {
            System.out.print("Ingrese el mes (ej. 10 - debe ser mayor a 0): ");
            mesScanner = entrada.nextInt();
            if (mesScanner <= 0) {
                System.out.println("Error: El mes debe ser un número positivo.");
            }
        } while (mesScanner <= 0);

        int diaScanner;
        do {
            System.out.print("Ingrese el día (ej. 31 - debe ser mayor a 0): ");
            diaScanner = entrada.nextInt();
            if (diaScanner <= 0) {
                System.out.println("Error: El día debe ser un número positivo.");
            }
        } while (diaScanner <= 0);

        int añoScanner;
        do {
            System.out.print("Ingrese el año (ej. 2023 - debe ser mayor a 0): ");
            añoScanner = entrada.nextInt();
            if (añoScanner <= 0) {
                System.out.println("Error: El año debe ser un número positivo.");
            }
        } while (añoScanner <= 0);

        // Creación del objeto Fecha 1
        Fecha fecha1 = new Fecha(mesScanner, diaScanner, añoScanner);

        System.out.print("\nFecha ingresada por consola: ");
        fecha1.mostrarFecha();

        // =================================================================
        // PARTE 2: Ingreso de datos mediante ventanas emergentes (JOptionPane)
        // =================================================================
        JOptionPane.showMessageDialog(null, "A continuación, ingresaremos una segunda fecha usando ventanas emergentes.");

        // Validación para el mes (Ventana)
        int mesVentana = 0;
        do {
            String mesString = JOptionPane.showInputDialog("Ingrese el mes (ej. 12 - debe ser mayor a 0):");
            mesVentana = Integer.parseInt(mesString);
            if (mesVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El mes debe ser un número positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (mesVentana <= 0);

        // Validación para el día (Ventana)
        int diaVentana = 0;
        do {
            String diaString = JOptionPane.showInputDialog("Ingrese el día (ej. 25 - debe ser mayor a 0):");
            diaVentana = Integer.parseInt(diaString);
            if (diaVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El día debe ser un número positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (diaVentana <= 0);

        // Validación para el año (Ventana)
        int añoVentana = 0;
        do {
            String anioString = JOptionPane.showInputDialog("Ingrese el año (ej. 2024 - debe ser mayor a 0):");
            añoVentana = Integer.parseInt(anioString);
            if (añoVentana <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El año debe ser un número positivo.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (añoVentana <= 0);

        // Creación del objeto Fecha 2
        Fecha fecha2 = new Fecha(mesVentana, diaVentana, añoVentana);

        // Preparar el mensaje de salida para la ventana emergente
        String mensajeSalida = String.format(
                "Fecha ingresada por ventanas emergentes:\n%d/%d/%d",
                fecha2.obtenerMes(),
                fecha2.obtenerDia(),
                fecha2.obtenerAnio()
        );

        JOptionPane.showMessageDialog(null, mensajeSalida, "Resultado", JOptionPane.INFORMATION_MESSAGE);

        entrada.close();
    }
}