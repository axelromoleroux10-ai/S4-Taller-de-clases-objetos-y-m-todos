package ejercicio3_14;

public class Fecha {
    private int mes;
    private int dia;
    private int año;

    public Fecha(int mes, int dia, int año) {
        this.mes = mes;
        this.dia = dia;
        this.año = año;
    }

    // Métodos establecer y obtener para mes
    public void establecerMes(int mes) {
        this.mes = mes;
    }
    public int obtenerMes() {
        return mes;
    }

    public void establecerDia(int dia) {
        this.dia = dia;
    }
    public int obtenerDia() {
        return dia;
    }

    public void establecerAnio(int anio) {
        this.año = anio;
    }
    public int obtenerAnio() {
        return año;
    }
    public void mostrarFecha() {
        System.out.printf("%d/%d/%d%n", mes, dia, año);
    }
}