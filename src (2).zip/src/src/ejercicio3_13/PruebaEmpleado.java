package ejercicio3_13;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PruebaEmpleado {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // --- Creación del Empleado 1 (Consola) ---
        System.out.println("--- Ingreso de datos para el Empleado 1 ---");
        System.out.print("Ingrese el primer nombre: ");
        String nombre1 = entrada.nextLine();
        System.out.print("Ingrese el apellido paterno: ");
        String apellido1 = entrada.nextLine();

        // Validación de salario positivo para Empleado 1
        double salario1;
        do {
            System.out.print("Ingrese el salario mensual (no puede ser negativo): ");
            salario1 = entrada.nextDouble();

            if (salario1 < 0) {
                System.out.println("Error: El salario debe ser un valor positivo o cero. Intente de nuevo.");
            }
        } while (salario1 < 0);

        Empleado empleado1 = new Empleado(nombre1, apellido1, salario1);

        // --- Creación del Empleado 2 (Ventanas Emergentes) ---
        String nombre2 = JOptionPane.showInputDialog(null,
                "Ingreso de datos para el Empleado 2\n\nIngrese el primer nombre:",
                "Datos Empleado 2", JOptionPane.QUESTION_MESSAGE);

        String apellido2 = JOptionPane.showInputDialog(null,
                "Ingrese el apellido paterno:",
                "Datos Empleado 2", JOptionPane.QUESTION_MESSAGE);

        // Validación de salario positivo para Empleado 2
        double salario2 = -1.0;
        do {
            String salarioStr = JOptionPane.showInputDialog(null,
                    "Ingrese el salario mensual (no puede ser negativo):",
                    "Datos Empleado 2", JOptionPane.QUESTION_MESSAGE);
            salario2 = Double.parseDouble(salarioStr);

            if (salario2 < 0) {
                JOptionPane.showMessageDialog(null,
                        "Error: El salario no puede ser un valor negativo.",
                        "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (salario2 < 0);

        Empleado empleado2 = new Empleado(nombre2, apellido2, salario2);

        // --- Mostrar salarios anuales iniciales con JOptionPane ---
        String mensajeInicial = String.format(
                "Salario anual inicial:\n\n1. %s %s: $%.2f\n2. %s %s: $%.2f",
                empleado1.obtenerPrimerNombre(), empleado1.obtenerApellidoPaterno(), empleado1.obtenerSalarioAnual(),
                empleado2.obtenerPrimerNombre(), empleado2.obtenerApellidoPaterno(), empleado2.obtenerSalarioAnual()
        );
        JOptionPane.showMessageDialog(null, mensajeInicial, "Salarios Anuales (Originales)", JOptionPane.INFORMATION_MESSAGE);

        // --- Aplicar aumento del 10% ---
        double aumento1 = empleado1.obtenerSalarioMensual() * 1.10;
        empleado1.establecerSalarioMensual(aumento1);

        double aumento2 = empleado2.obtenerSalarioMensual() * 1.10;
        empleado2.establecerSalarioMensual(aumento2);

        // --- Mostrar salarios anuales después del aumento con JOptionPane ---
        String mensajeFinal = String.format(
                "Salario anual con 10%% de aumento:\n\n1. %s %s: $%.2f\n2. %s %s: $%.2f",
                empleado1.obtenerPrimerNombre(), empleado1.obtenerApellidoPaterno(), empleado1.obtenerSalarioAnual(),
                empleado2.obtenerPrimerNombre(), empleado2.obtenerApellidoPaterno(), empleado2.obtenerSalarioAnual()
        );
        JOptionPane.showMessageDialog(null, mensajeFinal, "Salarios Anuales (Con Aumento)", JOptionPane.INFORMATION_MESSAGE);

        entrada.close();
    }
}