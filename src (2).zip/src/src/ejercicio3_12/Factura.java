package ejercicio3_12;


public class Factura {
    private String numeroPieza;
    private String descripcionPieza;
    private int cantidad;
    private double precioPorArticulo;

    // Constructor
    public Factura(String numeroPieza, String descripcionPieza, int cantidad, double precioPorArticulo) {
        this.numeroPieza = numeroPieza;
        this.descripcionPieza = descripcionPieza;
        establecerCantidad(cantidad);
        establecerPrecioPorArticulo(precioPorArticulo);
    }

    // Métodos
    public void establecerNumeroPieza(String numeroPieza) {
        this.numeroPieza = numeroPieza;
    }

    public String obtenerNumeroPieza() {
        return numeroPieza;
    }

    // Métodos establecer y obtener
    public void establecerDescripcionPieza(String descripcionPieza) {
        this.descripcionPieza = descripcionPieza;
    }

    public String obtenerDescripcionPieza() {
        return descripcionPieza;
    }

    // Métodos establecer y obtener para cantidad
    public void establecerCantidad(int cantidad) {
        if (cantidad < 0) {
            this.cantidad = 0;
        } else {
            this.cantidad = cantidad;
        }
    }

    public int obtenerCantidad() {
        return cantidad;
    }

    // Métodos establecer y obtener para el precio por articulo
    public void establecerPrecioPorArticulo(double precioPorArticulo) {
        if (precioPorArticulo < 0.0) {
            this.precioPorArticulo = 0.0;
        } else {
            this.precioPorArticulo = precioPorArticulo;
        }
    }

    public double obtenerPrecioPorArticulo() {
        return precioPorArticulo;
    }

    // Método para calcular el monto de la factura
    public double obtenerMontoFactura() {
        return cantidad * precioPorArticulo;
    }
}
