package ejercicio3_12;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PruebaFactura {
    public static void main(String[] args) {

        // =================================================================
        // PARTE 1: Ingreso de datos mediante la consola usando Scanner
        // =================================================================
        Scanner entrada = new Scanner(System.in);

        System.out.println("--- CREACIÓN DE FACTURA (Consola / Scanner) ---");
        System.out.print("Ingrese el número de pieza: ");
        String numPiezaScanner = entrada.nextLine();


        System.out.print("Ingrese la descripción de la pieza: ");
        String descPiezaScanner = entrada.nextLine();

        int cantidadScanner;
        do {
            System.out.print("Ingrese la cantidad comprada (no puede ser negativa): ");
            cantidadScanner = entrada.nextInt();

            if (cantidadScanner < 0) {
                System.out.println("Error: Por favor, ingrese un número positivo o cero.");
            }
        } while (cantidadScanner < 0);

        double precioScanner;
        do {
            System.out.print("Ingrese el precio por artículo (no puede ser negativo): ");
            precioScanner = entrada.nextDouble();

            if (precioScanner < 0) {
                System.out.println("Error: Por favor, ingrese un precio válido (positivo o cero).");
            }
        } while (precioScanner < 0);

        // Creación del objeto Factura 1
        Factura factura1 = new Factura(numPiezaScanner, descPiezaScanner, cantidadScanner, precioScanner);

        System.out.println("\n*** RESUMEN DE LA FACTURA 1 ***");
        System.out.printf("Número de pieza: %s%n", factura1.obtenerNumeroPieza());
        System.out.printf("Descripción: %s%n", factura1.obtenerDescripcionPieza());
        System.out.printf("Cantidad: %d%n", factura1.obtenerCantidad());
        System.out.printf("Precio por artículo: $%.2f%n", factura1.obtenerPrecioPorArticulo());
        System.out.printf("Monto Total de la Factura: $%.2f%n", factura1.obtenerMontoFactura());

        // =================================================================
        // PARTE 2: Ingreso de datos mediante ventanas emergentes (JOptionPane)
        // =================================================================
        JOptionPane.showMessageDialog(null, "A continuación, crearemos una segunda factura usando ventanas emergentes.");

        String numPiezaVentana = JOptionPane.showInputDialog("Ingrese el número de pieza:");
        String descPiezaVentana = JOptionPane.showInputDialog("Ingrese la descripción de la pieza:");

        int cantidadVentana = -1;
        do {
            String cantString = JOptionPane.showInputDialog("Ingrese la cantidad comprada (no puede ser negativa):");
            cantidadVentana = Integer.parseInt(cantString);

            if (cantidadVentana < 0) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese una cantidad positiva o cero.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (cantidadVentana < 0);

        double precioVentana = -1.0;
        do {
            String precioString = JOptionPane.showInputDialog("Ingrese el precio por artículo (no puede ser negativo):");
            precioVentana = Double.parseDouble(precioString);

            if (precioVentana < 0) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un precio válido (positivo o cero).", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        } while (precioVentana < 0);

// Creación del objeto Factura 2
        Factura factura2 = new Factura(numPiezaVentana, descPiezaVentana, cantidadVentana, precioVentana);
        String mensajeSalida = String.format(
                "*** RESUMEN DE LA FACTURA 2 ***\n" +
                        "Número de pieza: %s\n" +
                        "Descripción: %s\n" +
                        "Cantidad: %d\n" +
                        "Precio por artículo: $%.2f\n" +
                        "Monto Total de la Factura: $%.2f",
                factura2.obtenerNumeroPieza(),
                factura2.obtenerDescripcionPieza(),
                factura2.obtenerCantidad(),
                factura2.obtenerPrecioPorArticulo(),
                factura2.obtenerMontoFactura()
        );

        JOptionPane.showMessageDialog(null, mensajeSalida);

        entrada.close();
    }
}